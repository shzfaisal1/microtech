<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class make extends Model
{
    
    protected $guarded =[];
}
