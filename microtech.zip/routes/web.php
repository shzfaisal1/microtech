<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\CustomerLoginController;
use App\Http\Controllers\CompanyDetailController;
use App\Http\Controllers\FinancialYearController;
use App\Http\Controllers\TaxController;
use App\Http\Controllers\InvoiceTypeController;
use App\Http\Controllers\ReportTypeController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ExpenseTypeController;
use App\Http\Controllers\BuyerController;
use App\Http\Controllers\ConsigneeController;
use App\Http\Controllers\ReminderController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\CurrencyController;
use App\Http\Controllers\QuarterController;
use App\Http\Controllers\StockLocationController;
use App\Http\Controllers\LUTMasterController;
use App\Http\Controllers\DesignationController;
use App\Http\Controllers\RoleMasterController;
use App\Http\Controllers\ZoneController;
use App\Http\Controllers\LocationController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\ClientTypeController;
use App\Http\Controllers\VendorController;
use App\Http\Controllers\PurchaseInvoiceController;
use App\Http\Controllers\ReferenceController;  
use App\Http\Controllers\MakeController;   
use App\Http\Controllers\AttributeDetails;   
use App\Http\Controllers\AttributeValueController;   
use App\Http\Controllers\ModelDetailsController;   
use App\Http\Controllers\PurchasePayementController;  
use App\Http\Controllers\ClientNameController;   











 












Route::get('/', [LoginController::class, 'Login'])->name('login.page');
Route::post('login-submit', [LoginController::class, 'login_post'])->name('login.submit');

//Dahboard//
Route::get('/masters', [DashboardController::class, 'index'])->name('dashboard.index');

//
// Company Details Masters 
Route::get('/masters/company-details/company-details', [CompanyDetailController::class, 'index'])->name('masters.company-details.company-details');
Route::post('/masters/company-details/company-details', [CompanyDetailController::class, 'store'])->name('masters.company-details.store');
Route::get('/masters/company-details/view-file', [CompanyDetailController::class, 'view'])->name('masters.company-details.view-file');
Route::get('/masters/company-details/{id}/edit', [CompanyDetailController::class, 'edit'])->name('masters.company-details.edit');
Route::put('/masters/company-details/{id}', [CompanyDetailController::class, 'update'])->name('masters.company-details.update');
Route::delete('/masters/company-details/{id}', [CompanyDetailController::class, 'destroy'])->name('masters.company-details.destroy');

// Financial year

Route::group(['prefix'=>'/masters/financial-year','as'=>'financial.'], function(){

Route::get('/', [FinancialYearController::class, 'create'])->name('create');
Route::post('/', [FinancialYearController::class, 'store'])->name('store');
Route::get('/view', [FinancialYearController::class, 'index'])->name('index');
Route::get('/delete/{id}', [FinancialYearController::class, 'destroy'])->name('delete');
Route::get('/edit/{id}', [FinancialYearController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [FinancialYearController::class, 'update'])->name('update');


});


//  Tax //

Route::group(['prefix'=>'/masters/tex-details','as'=>'tax.'], function(){

Route::get('/', [TaxController::class, 'index'])->name('index');
Route::post('/', [TaxController::class, 'store'])->name('store');
Route::get('/view', [TaxController::class, 'view'])->name('list');
Route::get('/delete/{id}', [TaxController::class, 'destroy'])->name('delete');
Route::get('/edit/{id}', [TaxController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [TaxController::class, 'update'])->name('update');


});



///


// Invoice type//

Route::group(['prefix'=>'/masters/invoice-type','as'=>'invoice.'], function(){

Route::get('/', [InvoiceTypeController::class, 'create'])->name('create');
Route::post('/', [InvoiceTypeController::class, 'store'])->name('store');
Route::get('/view', [InvoiceTypeController::class, 'index'])->name('index');
Route::get('/edit/{id}', [InvoiceTypeController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [InvoiceTypeController::class, 'update'])->name('update');
Route::get('/delete/{id}', [InvoiceTypeController::class, 'destroy'])->name('delete');


});

///


// Report Type

Route::group(['prefix'=>'/masters/report-type','as'=>'report.'], function(){
Route::get('/', [ReportTypeController::class, 'create'])->name('create');
Route::get('/view', [ReportTypeController::class, 'index'])->name('index');
Route::get('/delete/{id}', [ReportTypeController::class, 'destroy'])->name('delete');
Route::get('/edit/{id}', [ReportTypeController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [ReportTypeController::class, 'update'])->name('update');
Route::post('/', [ReportTypeController::class, 'store'])->name('store');

});

///


// Expense Type///
Route::group(['prefix'=>'/masters/expense-type','as'=>'expense.'], function(){
Route::get('/', [ExpenseTypeController::class, 'create'])->name('create');
Route::get('/view', [ExpenseTypeController::class, 'index'])->name('index');
Route::post('/', [ExpenseTypeController::class, 'store'])->name('store');
Route::get('/edit/{id}', [ExpenseTypeController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [ExpenseTypeController::class, 'update'])->name('update');
Route::get('/delete/{id}', [ExpenseTypeController::class, 'destroy'])->name('delete');

});

////



/// Buyer //

Route::group(['prefix'=>'/masters/buyer','as'=>'buyer.'], function(){
Route::get('/', [BuyerController::class, 'create'])->name('create');
Route::get('/view', [BuyerController::class, 'index'])->name('index');
Route::post('/', [BuyerController::class, 'store'])->name('store');
Route::get('/edit/{id}', [BuyerController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [BuyerController::class, 'update'])->name('update');
Route::get('/delete/{id}', [BuyerController::class, 'destroy'])->name('delete');

});

////

//// consignee//

Route::group(['prefix'=>'/masters/consignee-name','as'=>'consignee.'], function(){
Route::get('/', [ConsigneeController::class, 'create'])->name('create');
Route::get('/view', [ConsigneeController::class, 'index'])->name('index');
Route::post('/', [ConsigneeController::class, 'store'])->name('store');
Route::get('/edit/{id}', [ConsigneeController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [ConsigneeController::class, 'update'])->name('update');
Route::get('/delete/{id}', [ConsigneeController::class, 'destroy'])->name('delete');

});


////

// reminder//

Route::group(['prefix'=>'/masters/reminder','as'=>'reminder.'], function(){

Route::get('/', [ReminderController::class, 'create'])->name('create');
Route::get('/view', [ReminderController::class, 'index'])->name('index');
Route::post('/', [ReminderController::class, 'store'])->name('store');
Route::get('/edit/{id}', [ReminderController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [ReminderController::class, 'update'])->name('update');
Route::get('/delete/{id}', [ReminderController::class, 'destroy'])->name('delete');

});


///

//account//

Route::group(['prefix'=>'/masters/account','as'=>'account.'], function(){

Route::get('/', [AccountController::class, 'create'])->name('create');
Route::get('/view', [AccountController::class, 'index'])->name('index');
Route::post('/', [AccountController::class, 'store'])->name('store');
Route::get('/edit/{id}', [AccountController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [AccountController::class, 'update'])->name('update');
Route::get('/delete/{id}', [AccountController::class, 'destroy'])->name('delete');

});

//


/// currency //

Route::group(['prefix'=>'/masters/currency','as'=>'currency.'], function(){

Route::get('/', [CurrencyController::class, 'create'])->name('create');
Route::get('/view', [CurrencyController::class, 'index'])->name('index');
Route::post('/', [CurrencyController::class, 'store'])->name('store');
Route::get('/edit/{id}', [CurrencyController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [CurrencyController::class, 'update'])->name('update');
Route::get('/delete/{id}', [CurrencyController::class, 'destroy'])->name('delete');

});


///


//Quarter Master
Route::group(['prefix'=>'/masters/quarter','as'=>'quarter.'], function(){

Route::get('/', [QuarterController::class, 'create'])->name('create');
Route::get('/view', [QuarterController::class, 'index'])->name('index');
Route::post('/', [QuarterController::class, 'store'])->name('store');
Route::get('/edit/{id}', [QuarterController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [QuarterController::class, 'update'])->name('update');
Route::get('/delete/{id}', [QuarterController::class, 'destroy'])->name('delete');

});
//
// location master
Route::group(['prefix'=>'/masters/location-stock','as'=>'location.'], function(){

Route::get('/', [StockLocationController::class, 'create'])->name('create');
Route::get('/view', [StockLocationController::class, 'index'])->name('index');
Route::post('/', [StockLocationController::class, 'store'])->name('store');
Route::get('/edit/{id}', [StockLocationController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [StockLocationController::class, 'update'])->name('update');
Route::get('/delete/{id}', [StockLocationController::class, 'destroy'])->name('delete');

});

//

//LUT//
Route::group(['prefix'=>'/masters/LUT-master','as'=>'LUT.'], function(){

Route::get('/', [LUTMasterController::class, 'create'])->name('create');
Route::get('/view', [LUTMasterController::class, 'index'])->name('index');
Route::post('/', [LUTMasterController::class, 'store'])->name('store');
Route::get('/edit/{id}', [LUTMasterController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [LUTMasterController::class, 'update'])->name('update');
Route::get('/delete/{id}', [LUTMasterController::class, 'destroy'])->name('delete');

});

//

//Designation//
Route::group(['prefix'=>'/masters/employees-designation','as'=>'designation.'], function(){

Route::get('/', [DesignationController::class, 'create'])->name('create');
Route::get('/view', [DesignationController::class, 'index'])->name('index');
Route::post('/', [DesignationController::class, 'store'])->name('store');
Route::get('/edit/{id}', [DesignationController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [DesignationController::class, 'update'])->name('update');
Route::get('/delete/{id}', [DesignationController::class, 'destroy'])->name('delete');

});

//

/// role//

Route::group(['prefix'=>'/masters/role-master','as'=>'role.'], function(){

Route::get('/', [RoleMasterController::class, 'create'])->name('create');
Route::get('/view', [RoleMasterController::class, 'index'])->name('index');
Route::post('/', [RoleMasterController::class, 'store'])->name('store');
Route::get('/edit/{id}', [RoleMasterController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [RoleMasterController::class, 'update'])->name('update');
Route::get('/delete/{id}', [RoleMasterController::class, 'destroy'])->name('delete');

});


///


// Zone Master
Route::group(['prefix'=>'/masters/zone-master','as'=>'zone.'], function(){  
Route::get('/', [ZoneController::class, 'create'])->name('create');
Route::get('/view', [ZoneController::class, 'index'])->name('index');
Route::post('/', [ZoneController::class, 'store'])->name('store');
Route::get('/edit/{id}', [ZoneController::class, 'edit'])->name('edit');
Route::post('/update/{id}', [ZoneController::class, 'update'])->name('update');
Route::get('/delete/{id}', [ZoneController::class, 'destroy'])->name('delete');
});
///


Route::group(['prefix'=>'/masters/location-master'], function(){  
    Route::get('/', [LocationController::class, 'index'])->name('locations.index');
    Route::get('/create', [LocationController::class, 'create'])->name('locations.create');
    Route::post('/store', [LocationController::class, 'store'])->name('locations.store');
    Route::get('/edit/{id}', [LocationController::class, 'edit'])->name('locations.edit');
    Route::post('/update/{id}', [LocationController::class, 'update'])->name('locations.update');
    Route::get('/delete/{id}', [LocationController::class, 'destroy'])->name('locations.delete');
});

Route::group(['prefix'=>'/masters/client'], function(){ 
    Route::get('/', [ClientController::class, 'index'])->name('client.index');
    Route::get('/create', [ClientController::class, 'create'])->name('client.create');
    Route::post('/store', [ClientController::class, 'store'])->name('client.store');
    Route::get('/edit/{id}', [ClientController::class, 'edit'])->name('client.edit');
    Route::post('/update/{id}', [ClientController::class, 'update'])->name('client.update');
    Route::get('/delete/{id}', [ClientController::class, 'destroy'])->name('client.delete');
});

//vendor master
Route::group(['prefix'=>'/masters/vendor'], function(){ 
    Route::get('/', [VendorController::class, 'index'])->name('vendor.index');
    Route::get('/create', [VendorController::class, 'create'])->name('vendor.create');
    Route::post('/store', [VendorController::class, 'store'])->name('vendor.store');
    Route::get('/edit/{id}', [VendorController::class, 'edit'])->name('vendor.edit');
    Route::put('/update/{id}', [VendorController::class, 'update'])->name('vendor.update');
    Route::get('/delete/{id}', [VendorController::class, 'destroy'])->name('vendor.delete');
});
//Client Type Master
Route::group(['prefix'=>'/masters/client-type'], function(){ 
    Route::get('/', [ClientTypeController::class, 'index'])->name('client-type.index');
    Route::get('/create', [ClientTypeController::class, 'create'])->name('client-type.create');
    Route::post('/store', [ClientTypeController::class, 'store'])->name('client-type.store');
    Route::get('/edit/{id}', [ClientTypeController::class, 'edit'])->name('client-type.edit');
    Route::post('/update/{id}', [ClientTypeController::class, 'update'])->name('client-type.update');
    Route::get('/delete/{id}', [ClientTypeController::class, 'destroy'])->name('client-type.delete');
});

///purchase invoice
Route::group(['prefix'=>'/masters/purchase-invoice'], function(){
    Route::get('/', [PurchaseInvoiceController::class, 'index'])->name('purchase-invoice.index');
    Route::get('/create', [PurchaseInvoiceController::class, 'create'])->name('purchase-invoice.create');       
    Route::post('/store', [PurchaseInvoiceController::class, 'store'])->name('purchase-invoice.store');
    Route::get('/edit/{id}', [PurchaseInvoiceController::class, 'edit'])->name('purchase-invoice.edit');
    Route::post('/update/{id}', [PurchaseInvoiceController::class, 'update'])->name('purchase-invoice.update');
    Route::get('/delete/{id}', [PurchaseInvoiceController::class, 'destroy'])->name('purchase-invoice.delete');
    Route::get('/show/{id}', [PurchaseInvoiceController::class, 'show'])->name('purchase-invoice.show');
    Route::get('/search', [PurchaseInvoiceController::class, 'search'])->name('purchase-invoice.search');
    Route::get('summary-data', [PurchaseInvoiceController::class, 'getSummaryData'])->name('purchase-invoice.summary-data');


});

//reference
Route::group(['prefix'=>'/masters/reference'], function(){
    Route::get('/', [App\Http\Controllers\ReferenceController::class, 'index'])->name('reference.index');
    Route::get('/create', [App\Http\Controllers\ReferenceController::class, 'create'])->name('reference.create');
    Route::post('/store', [App\Http\Controllers\ReferenceController::class, 'store'])->name('reference.store');
    Route::get('/edit/{id}', [App\Http\Controllers\ReferenceController::class, 'edit'])->name('reference.edit');
    Route::post('/update/{id}', [App\Http\Controllers\ReferenceController::class, 'update'])->name('reference.update');
    Route::get('/delete/{id}', [App\Http\Controllers\ReferenceController::class, 'destroy'])->name('reference.delete');
});
//
//

// po-entry//
Route::group(['prefix'=>'/masters/po-entry'], function(){

    Route::get('/', [App\Http\Controllers\POEntryController::class, 'index'])->name('po.index');
    Route::get('/create', [App\Http\Controllers\POEntryController::class, 'create'])->name('po.create');
    Route::get('/edit/{id}', [App\Http\Controllers\POEntryController::class, 'edit_data'])->name('po.edit');
    Route::put('/update/{id}', [App\Http\Controllers\POEntryController::class, 'update'])->name('po.update');
    Route::get('/delete/{id}', [App\Http\Controllers\POEntryController::class, 'destroy'])->name('po.delete');
    Route::post('/vendor', [App\Http\Controllers\POEntryController::class, 'vendorContacts'])->name('vendor.contact');
    Route::post('/po/store', [App\Http\Controllers\POEntryController::class, 'store'])->name('po.store');

    
});
    Route::get('po/{id}', [App\Http\Controllers\POEntryController::class, 'view'])->name('po.view');


///
   Route::post('/currency/value', [App\Http\Controllers\POEntryController::class, 'getCurrencyVal'])->name('currency.value');

////
//make //

Route::group(['prefix'=>'/masters/make','as'=>'make.'], function(){  

Route::get('/', [MakeController::class, 'create'])->name('create');
Route::get('/view', [MakeController::class, 'index'])->name('index');
Route::post('/', [MakeController::class, 'store'])->name('store');
Route::get('/edit/{id}', [MakeController::class, 'edit'])->name('edit');
Route::put('/update/{id}', [MakeController::class, 'update'])->name('update');
Route::get('/delete/{id}', [MakeController::class, 'destroy'])->name('delete');

});

///

//attribute value//

Route::group(['prefix'=>'/masters/attribute-details','as'=>'attribute.'], function(){  

Route::get('/', [AttributeDetails::class, 'create'])->name('create');
Route::get('/view', [AttributeDetails::class, 'index'])->name('index');
Route::post('/', [AttributeDetails::class, 'store'])->name('store');
Route::get('/edit/{id}', [AttributeDetails::class, 'edit'])->name('edit');
Route::put('/update/{id}', [AttributeDetails::class, 'update'])->name('update');
Route::delete('/delete/{id}', [AttributeDetails::class, 'destroy'])->name('delete');

});

///


//attribute value//

Route::group(['prefix'=>'/masters/attribute-value','as'=>'attribute.value.'], function(){  

Route::get('/', [AttributeValueController::class, 'create'])->name('create');
Route::get('/view', [AttributeValueController::class, 'index'])->name('index');
Route::post('/', [AttributeValueController::class, 'store'])->name('store');
Route::get('/edit/{id}', [AttributeValueController::class, 'edit'])->name('edit');
Route::put('/update/{id}', [AttributeValueController::class, 'update'])->name('update');
Route::delete('/delete/{id}', [AttributeValueController::class, 'destroy'])->name('delete');

});

///


/// model detail//
Route::group(['prefix'=>'/masters/model','as'=>'model.'], function(){  

Route::get('/', [ModelDetailsController::class, 'create'])->name('create');
Route::get('/view', [ModelDetailsController::class, 'index'])->name('index');
Route::post('/', [ModelDetailsController::class, 'store'])->name('store');
Route::get('/edit/{id}', [ModelDetailsController::class, 'edit'])->name('edit');
Route::put('/update/{id}', [ModelDetailsController::class, 'update'])->name('update');
Route::delete('/delete/{id}', [ModelDetailsController::class, 'destroy'])->name('delete');

});


//


// purchase-payment //

/// model detail//
Route::group(['prefix'=>'/masters/purchase-payment','as'=>'purchase.payment.'], function(){  

Route::get('/', [PurchasePayementController::class, 'create'])->name('create');
Route::get('/view', [PurchasePayementController::class, 'index'])->name('index');
Route::post('/', [PurchasePayementController::class, 'store'])->name('store');
Route::get('/edit/{id}', [PurchasePayementController::class, 'edit'])->name('edit');
Route::put('/update/{id}', [PurchasePayementController::class, 'update'])->name('update');
Route::delete('/delete/{id}', [PurchasePayementController::class, 'destroy'])->name('delete');
Route::post('/get/vendor-balance', [PurchasePayementController::class, 'getBalanceVendor'])->name('get_balance');


});


//
// client name//
Route::group(['prefix'=>'/masters/client-name','as'=>'client.name.'], function(){  

Route::get('/', [ClientNameController::class, 'create'])->name('create');
Route::get('/view', [ClientNameController::class, 'index'])->name('index');
Route::post('/', [ClientNameController::class, 'store'])->name('store');
Route::get('/edit/{id}', [ClientNameController::class, 'edit'])->name('edit');
Route::put('/update/{id}', [ClientNameController::class, 'update'])->name('update');
Route::delete('/delete/{id}', [ClientNameController::class, 'destroy'])->name('delete');
Route::post('/get/vendor-balance', [ClientNameController::class, 'getBalanceVendor'])->name('get_balance');


});
//

Route::get('/client-details', function () {
    return view('client-details');
});

Route::get('/location-master', function () {
    return view('location-master');
});

Route::get('/client-type-master', function () {
    return view('client-type-master');
});

Route::get('/purchase-invoice', function () {
    return view('purchase-invoice');
});

Route::get('/Product-Master-Model-Details', function () {
    return view('Product-Master-Model-Details');
});

Route::get('/currency-master', function () {
    return view('currency-master');
});

Route::get('/product-master', function () {
    return view('product-master');
});

Route::get('/po-entry', function () {
    return view('po-entry');
});

Route::get('/view-all-po-entry', function () {
    return view('view-all-po-entry');
});

Route::get('/po-summary', function () {
    return view('po-summary');
});

Route::get('/product-master-attribute-details', function () {
    return view('product-master-attribute-details');
});

Route::get('/product-master-attribute-value', function () {
    return View('product-master-attribute-value');
});

Route::get('/buyer-master', function () {
    return view('buyer-master');
});

Route::get('/consignee-master', function () {
    return view('consignee-master');
});

Route::get('/financial-year-master', function () {
    return View('financial-year-master');
});

Route::get('/company-details', function () {
    return View('company-details');
});

Route::get('/client-group-master', function () {
    return View('client-group-master');
});

Route::get('/view-all-company', function () {
    return View('view-all-company');
});

Route::get('/zone-master', function () {
    return view('zone-master');
});

Route::get('/vendor-master', function () {
    return View('vendor-master');
});

Route::get('/view-all-purchase-invoice', function () {
    return View('view-all-purchase-invoice');
});

Route::get('/purchase-summary', function () {
    return View('purchase-summary');
});

Route::get('/payment', function () {
    return View('payment');
});

Route::get('/payment-history', function () {
    return View('/payment-history');
});

Route::get('purchase-invoice-wise-payment', function () {
    return View('/purchase-invoice-wise-payment');
});

Route::get('/account-master', function () {
    return view('/account-master');
});

Route::get('/view-all-accounts', function () {
    return View('view-all-accounts');
});

Route::get('/sales-quotation', function () {
    return View('/sales-quotation');
});

Route::get('/employee-details', function () {
    return View('employee-details');
});

Route::get('view-all-employee-list', function () {
    return View('view-all-employee-list');
});



Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


Route::get('/customer-login', [CustomerLoginController::class, 'showLoginForm'])->name('customer.login');
Route::post('/customer-login', [CustomerLoginController::class, 'login'])->name('customer.login.submit');

Route::get('/customer-dashboard', function () {
    return view('index');
    Route::post('/customer-logout', [CustomerLoginController::class, 'logout'])->name('customer.logout');
})->name('customer.dashboard')->middleware(['auth']);
