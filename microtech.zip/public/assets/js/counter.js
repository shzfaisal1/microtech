(function($) {
    "use strict";
	
	$('.counter').countUp();
	
})(jQuery);