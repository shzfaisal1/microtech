

<?php $__env->startSection('main'); ?>
<div class="search-client-info">
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-body">

                    <?php if(session('invoice_delete')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('invoice_delete')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table id="invoiceTable" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Invoice Type</th>
                                    <th>Stamp Description</th>
                                    <th>Unstamp Description</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>



<script>
 $(document).ready(function() {

    
    $.fn.dataTable.ext.errMode = 'throw';
    $('#invoiceTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('invoice.index')); ?>",
        columns: [
                { data: 'id', name: 'id' },
                { data: 'invoice_type', name: 'invoice_type' },
                { data: 'stamp_description', name: 'stamp_description' },
                { data: 'unstamp_description', name: 'unstamp_description' },
                { data: 'action', name: 'action', orderable: false, searchable: false },
        ]
    });


    
});



</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\microtech\resources\views\masters\invoice-type\list_invoice.blade.php ENDPATH**/ ?>