

<?php $__env->startSection('main'); ?>

<!--Page header-->
<div class="page-header">
    <div class="page-leftheader">
        <h4 class="page-title">Company Details</h4>
        <ol class="breadcrumb pl-0">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
        </ol>
    </div>

</div>

<form action="<?php echo e(route('masters.company-details.update', $company->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="search-client-info">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Edit Company Invoice</h3>
                    </div>
                    <div class="card-body">

                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="company_name">Company Name <span class="text-danger">*</span> :</label>
                                    <input type="hidden" name="id" id="company_id" value="<?php echo e($company->id); ?>">
                                    <input type="text" class="form-control" id="company_name" name="company_name" value="<?php echo e(old('company_name', $company->company_name)); ?>">
                                </div>
                            </div>

                            <div class="col">
                                <div class="form-group">
                                    <label for="contact_num">Contact No :</label>
                                    <div class="input-group mb-3">
                                        <input type="number" class="form-control" name="contact_num" id="contact_num" value="<?php echo e(old('contact_num', $company->contact_num)); ?>">
                                        <input type="number" class="form-control" name="contact_num1" id="contact_num1" value="<?php echo e(old('contact_num1', $company->contact_num1)); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Repeat this pattern for all fields, pre-filling with $company data -->
                        <!-- Example for email -->
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="email_id">Email ID :</label>
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" name="email_id" id="email_id" value="<?php echo e(old('email_id', $company->email_id)); ?>">
                                        <input type="text" class="form-control" name="email_id1" id="email_id1" value="<?php echo e(old('email_id1', $company->email_id1)); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Repeat for other fields... -->

                        <div class="row">
                            <div class="col text-center">
                                <div class="d-inline-block">
                                    <button type="submit" class="btn btn-primary me-2">Update</button>
                                    <a href="<?php echo e(route('masters.company-details.view-file')); ?>" class="btn btn-secondary">Cancel</a>
                                </div>
                            </div>
                        </div>

                    </div> <!-- end card-body -->
                </div> <!-- end card -->
            </div> <!-- end col -->
        </div> <!-- end row -->
    </div> <!-- end search-client-info -->
</form>

<!-- End search-client-info -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\microtech\resources\views\masters\company-details\company-edit.blade.php ENDPATH**/ ?>