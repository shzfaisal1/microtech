

<?php $__env->startSection('main'); ?>
<form action="<?php echo e(route('client-type.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="card">
        <div class="card-header"><h3>Add Client Type</h3></div>
        <div class="card-body">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <p><?php echo e($error); ?></p> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <div class="form-group">
                <label>Client Type Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>

            <button class="btn btn-primary">Add</button>
            <a href="<?php echo e(route('client-type.index')); ?>" class="btn btn-secondary">Cancel</a>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\microtech\resources\views\masters\client_type\add.blade.php ENDPATH**/ ?>