

<?php $__env->startSection('main'); ?>

<!--Page header-->
<div class="page-header">
    <div class="page-leftheader">
        <h4 class="page-title">Edit Account Master</h4>
        <ol class="breadcrumb pl-0">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
        </ol>
    </div>
</div>
<!--End Page header-->

<!-- Edit form -->
<form action="<?php echo e(route('account.update', $account->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>


    <div class="search-client-info">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="card">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="card-header">
                        <h3 class="card-title">Edit Account Master Details</h3>
                    </div>
                    <div class="card-body">

                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="account_name">Account Name <span class="text-danger">*</span> :</label>
                                    <input type="text" class="form-control" name="account_name"
                                        value="<?php echo e(old('account_name', $account->account_name)); ?>">

                                    <div class="mt-2">
                                        <input type="checkbox" name="is_Default" id="financial_year" value="1"
                                            <?php echo e(old('is_Default', $account->is_Default) ? 'checked' : ''); ?>>
                                        <label for="financial_year">Set as current financial year</label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="account_holder_name">Account Holder Name <span class="text-danger">*</span> :</label>
                                    <input type="text" class="form-control" name="account_holder_name"
                                        value="<?php echo e(old('account_holder_name', $account->account_holder_name)); ?>">
                                </div>
                            </div>

                            <div class="col">
                                <div class="form-group">
                                    <label for="account_holder_add">Account Holder Address <span class="text-danger">*</span> :</label>
                                    <input type="text" class="form-control" name="account_holder_add"
                                        value="<?php echo e(old('account_holder_add', $account->account_holder_add)); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="account_no">Account Number <span class="text-danger">*</span> :</label>
                                    <input type="number" class="form-control" name="account_no"
                                        value="<?php echo e(old('account_no', $account->account_no)); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="bank_name">Bank Name <span class="text-danger">*</span> :</label>
                                    <input type="text" class="form-control" name="bank_name"
                                        value="<?php echo e(old('bank_name', $account->bank_name)); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="branch">Branch <span class="text-danger">*</span> :</label>
                                    <input type="text" class="form-control" name="branch"
                                        value="<?php echo e(old('branch', $account->branch)); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="ifsc">IFSC <span class="text-danger">*</span> :</label>
                                    <input type="text" class="form-control" name="ifsc"
                                        value="<?php echo e(old('ifsc', $account->ifsc)); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="bank_add">Bank Address <span class="text-danger">*</span> :</label>
                                    <input type="text" class="form-control" name="bank_add"
                                        value="<?php echo e(old('bank_add', $account->bank_add)); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col text-center">
                                <div class="d-inline-block">
                                    <button type="submit" class="btn btn-success me-2">
                                        Update
                                    </button>
                                    <a href="<?php echo e(route('account.index')); ?>" class="btn btn-secondary">Cancel</a>
                                </div>
                            </div>
                        </div>

                    </div> <!-- /.card-body -->
                </div> <!-- /.card -->
            </div>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\microtech\resources\views\masters\account\edit.blade.php ENDPATH**/ ?>