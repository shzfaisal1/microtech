<!-- footer area start-->
<footer>
    <div class="footer-area">
        <p>© Copyright 2018. All right reserved. Template by <a href="https://colorlib.com/wp/">Colorlib</a>.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<!-- footer area end-->
<?php /**PATH C:\xampp\htdocs\microtech\resources\views\layouts\partials\footer.blade.php ENDPATH**/ ?>