

<?php $__env->startSection('main'); ?>
<div class="search-client-info">
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="card">
				<div class="card-body">
					<div class="table-responsive">
						<table id="example" class="table table-striped table-bordered w-100">
							<thead>
								<tr>
									<th class="wd-15p">Sr.No</th>
									<th class="wd-15p">Company Name</th>
									<th class="wd-15p">Print As</th>
									<th class="wd-15p">Company Prefix</th>
									<!-- <th class="wd-15p">Type of code</th>
									<th class="wd-15p">Code</th> -->
									<!-- <th class="wd-15p">Stamping</th> -->
									<th class="wd-15p">EMAIL ID</th>
									<th class="wd-15p">Address</th>
									<th class="wd-15p">VAT No</th>
									<th class="wd-15p">VC Date</th>
									<th class="wd-15p">Stock Location</th>
									<!-- <th class="wd-15p">Quantity</th> -->
									<th class="wd-15p">Price</th>
									<th class="wd-15p">Total</th>
									<th class="wd-15p">Price in INR</th>
									<th class="wd-25p">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($loop->iteration); ?></td>
									<td><?php echo e($company->company_name); ?></td>
									<td><?php echo e($company->print_as); ?>

										<br>
										<?php echo e($company->print_as1); ?>

									</td>
									<td> <?php echo e($company->company_prefix); ?></td>
									<!-- <td></td>
									<td></td> -->
									<!-- <td></td> -->
									<td> <?php echo e($company->email_id); ?>

										<br>
										<?php echo e($company->email_id1); ?>

									</td>
									<td><?php echo e($company->address); ?></td>
									<td><?php echo e($company->vat_tin); ?></td>
									<td><?php echo e($company ->vat_tin_date); ?></td>
									<td><?php echo e($company ->pan_no); ?></td>
									<!-- <td></td> -->
									<td><?php echo e($company ->cst_tin); ?></td>
									<td><?php echo e($company ->cst_tin_date); ?></td>
									<td><?php echo e($company ->pt_no); ?></td>
									<td>
										
										<a href="<?php echo e(route('masters.company-details.edit', $company->id)); ?>" class="btn btn-success btn-edit" data-id="<?php echo e($company->id); ?>">
											<i class="fa fa-edit"></i>
										</a>

										
										<form action="<?php echo e(route('masters.company-details.destroy', $company->id)); ?>" method="POST" style="display:inline-block;">
											<?php echo csrf_field(); ?>
											<?php echo method_field('DELETE'); ?>
											<button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this company?');">
												<i class="fa fa-trash"></i>
											</button>
										</form>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


								<!-- Edit Company Modal -->
								<div class="modal fade" id="editCompanyModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
									<div class="modal-dialog">
										<form id="editCompanyForm">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title">Edit Company</h5>
													<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
												</div>
												<div class="modal-body">
													<input type="hidden" name="id" id="company_id">

													<div class="mb-3">
														<label>Company Name</label>
														<input type="text" name="company_name" id="company_name" class="form-control" required>
													</div>

													<div class="mb-3">
														<label>Email</label>
														<input type="email" name="email_id" id="email_id" class="form-control">
													</div>

													<!-- Add other fields as needed -->
												</div>

												<div class="modal-footer">
													<button type="submit" class="btn btn-primary">Update</button>
												</div>
											</div>
										</form>
									</div>
								</div>

								<!-- <tr>
									<td>Donna</td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td>
										<a href=""><i class="fa fa-edit"></i></a>
										<a href=""><i class="fa fa-trash"></i></a>
									</td>
								</tr> -->

							</tbody>
						</table>
					</div>
					<!-- <div class="row">
						<div class="col">
							<button type="submit" class="btn btn-primary d-block m-auto">Add</button>
						</div>
					</div> -->
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\microtech\resources\views\masters\company-details\All-view.blade.php ENDPATH**/ ?>