

<?php $__env->startSection('main'); ?>

<!--Page header-->
<div class="page-header">
    <div class="page-leftheader">
        <h4 class="page-title">Financial Year</h4>
        <ol class="breadcrumb pl-0">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
        </ol>
    </div>
</div>
<!--End Page header-->

<form action="<?php echo e(route('financial.update', $financialYear->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('POST'); ?>

    <div class="search-client-info">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="card">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(session('Financial_Year')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('Financial_Year')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="card-header">
                        <h3 class="card-title">Edit Financial Year</h3>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label>Financial Year <span class="text-danger">*</span> :</label>
                                    <input type="text" class="form-control" name="financial_year"
                                        value="<?php echo e(old('financial_year', $financialYear->financial_year)); ?>">

                                    <div class="mt-2">
                                        <input type="checkbox" name="is_Default" value="1"
                                            <?php echo e($financialYear->is_Default == 1 ? 'checked' : ''); ?>>
                                        <label for="is_Default">Set as current financial year</label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label>From Date <span class="text-danger">*</span> :</label>
                                    <input type="date" class="form-control" name="from_date"
                                        value="<?php echo e(old('from_date', $financialYear->from_date)); ?>">
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label>To Date <span class="text-danger">*</span> :</label>
                                    <input type="date" class="form-control" name="to_date"
                                        value="<?php echo e(old('to_date', $financialYear->to_date)); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Description:</label>
                            <textarea class="form-control" name="description" rows="3"><?php echo e(old('description', $financialYear->description)); ?></textarea>
                        </div>

                        <div class="text-center mt-4">
                            <button type="submit" class="btn btn-primary">Update</button>
                            <a href="<?php echo e(route('financial.index')); ?>" class="btn btn-secondary">Cancel</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\microtech\resources\views\masters\financial-year\final-year-edit.blade.php ENDPATH**/ ?>