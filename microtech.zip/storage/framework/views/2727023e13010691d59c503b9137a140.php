

<?php $__env->startSection('main'); ?>
<div class="search-client-info">
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-body">

                    <?php if(session('expense_delete')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('expense_delete')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('update_expenseType')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('update_expenseType')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table id="lut_table" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>LUT Number</th>
                                    <th>LUT Note</th>
                                    <th>Financial Year</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        $.fn.dataTable.ext.errMode = 'throw';
        $('#lut_table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('LUT.index')); ?>", 
            columns: [
                { data: 'id', name: 'id' },
                { data: 'LUT_number', name: 'LUT_number' },
                { data: 'LUT_note', name: 'LUT_note' },
                { data: 'financial_year', name: 'financial_year' },
                { data: 'action', name: 'action', orderable: false, searchable: false }
            ]
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\microtech\resources\views\masters\LUT-master\list.blade.php ENDPATH**/ ?>