Attached you will find requested report.
<?php /**PATH C:\xampp\htdocs\microtech\vendor\yajra\laravel-datatables-export\src\resources\views\export-email.blade.php ENDPATH**/ ?>