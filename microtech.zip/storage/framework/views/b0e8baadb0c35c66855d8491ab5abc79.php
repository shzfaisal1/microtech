

<?php $__env->startSection('main'); ?>
<div class="search-client-info">
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-body">

                    <?php if(session('reminder_delete')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('reminder_delete')); ?>

                    </div>
                    <?php endif; ?>
                     <?php if(session('add_reminder')): ?>

                        <div class="alert alert-success">
                            <?php echo e(session('add_reminder')); ?>

                        </div>
                        <?php endif; ?>

                        <?php if(session('update_reminder')): ?>

                        <div class="alert alert-success">
                            <?php echo e(session('update_reminder')); ?>

                        </div>
                        <?php endif; ?>

                    <div class="table-responsive">
                        <table id="reminder" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Reminder Value </th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>



<script>
 $(document).ready(function() {
    $.fn.dataTable.ext.errMode = 'throw';
    $('#reminder').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('reminder.index')); ?>",
        columns: [
            { data: 'id', name: 'id' },
            { data: 'reminder_value', name: 'reminder_value' },
            { data: 'action', name: 'action', orderable: false, searchable: false }
        ]
    });


    
});



</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\microtech\resources\views\masters\reminder\list.blade.php ENDPATH**/ ?>