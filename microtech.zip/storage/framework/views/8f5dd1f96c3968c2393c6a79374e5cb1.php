

<?php $__env->startSection('main'); ?>
<div class="search-client-info">
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-body">

                    <?php if(session('consignee_delete')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('consignee_delete')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table id="consignee" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Consignee Name </th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>



<script>
 $(document).ready(function() {
    $.fn.dataTable.ext.errMode = 'throw';
    $('#consignee').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('consignee.index')); ?>",
        columns: [
            { data: 'id', name: 'id' },
            { data: 'name', name: 'name' },
            { data: 'action', name: 'action', orderable: false, searchable: false }
        ]
    });


    
});



</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\microtech\resources\views\masters\consignee\list_consignee.blade.php ENDPATH**/ ?>