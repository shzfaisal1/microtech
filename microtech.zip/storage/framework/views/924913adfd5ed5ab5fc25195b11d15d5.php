<!-- header area start -->
<div class="header-area">
    <div class="row align-items-center">
        <!-- nav and search button -->
        <div class="col-md-6 col-sm-8 clearfix">
            <div class="nav-btn">
                <a href="javascript:void(0)" class="navbar-brand" id="sidebarToggle"><i
                        class="fa fa-bars text-light"></i></a>
            </div>
        </div>
        <!-- profile info & task notification -->
        <div class="col-md-6 col-sm-4 clearfix">
            <ul class="notification-area pull-right">
                <li id="full-view"><i class="ti-fullscreen text-white"></i></li>
                <li>
                    <div class="">
                        <?php echo $__env->make('layouts.partials.logout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </li>
                <li id="full-view-exit"><i class="ti-zoom-out text-white"></i></li>
                

            </ul>
        </div>
    </div>
</div>
<!-- header area end -->
<?php /**PATH C:\xampp\htdocs\microtech\resources\views\layouts\partials\header.blade.php ENDPATH**/ ?>