

<?php $__env->startSection('main'); ?>
<div class="search-client-info">
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-body">

              <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                      <?php if(session('delete')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('delete')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                    <div class="table-responsive">
                        <table id="currency" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Currency Name</th>
                                    <th>Currency Value</th>
                                    <th>Symbol Currency</th>                              
                                    <th>Default</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>



<script>
 $(document).ready(function() {
    $.fn.dataTable.ext.errMode = 'throw';
    $('#currency').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('currency.index')); ?>",
        columns: [
           { data: 'id', name: 'id' },
                { data: 'currency_name', name: 'currency_name' },
                { data: 'value', name: 'value' },
                { data: 'symbol', name: 'symbol' },
                 { data: 'is_Default', name: 'is_Default', orderable: false, searchable: false },            
                { data: 'action', name: 'action', orderable: false, searchable: false },
        ]
    });


    
});



</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\microtech\resources\views\masters\currency\list.blade.php ENDPATH**/ ?>