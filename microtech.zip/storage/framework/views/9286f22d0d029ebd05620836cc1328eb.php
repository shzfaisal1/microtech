

<?php $__env->startSection('main'); ?>

<!--Page header-->
						<div class="page-header">
							<div class="page-leftheader">
								<h4 class="page-title">Account Master</h4>
								<ol class="breadcrumb pl-0">
									<li class="breadcrumb-item"><a href="#">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Dashboard</li>
								</ol>
							</div>
							<!-- <div class="page-rightheader">
								<div class="ml-3 ml-auto d-flex">
									<div class="border-right pr-4 mt-2 d-xl-block">
										<p class="text-muted mb-1">Category</p>
										<h6 class="font-weight-semibold mb-0">All Categories</h6>
									</div>
									<div class="border-right pl-4 pr-4 mt-2 d-xl-block">
										<p class="text-muted mb-0">Customer Rating</p>
										<div class="wideget-user-rating">
											<a href="#">
												<i class="fa fa-star text-warning"></i>
											</a>
											<a href="#">
												<i class="fa fa-star text-warning"></i>
											</a>
											<a href="#">
												<i class="fa fa-star text-warning"></i>
											</a>
											<a href="#">
												<i class="fa fa-star text-warning"></i>
											</a>
											<a href="#">
												<i class="fa fa-star-o text-warning mr-1"></i>
											</a>
											<span class="">(4.5/5)</span>
										</div>
									</div>
									<span class="pg-header">
										<a href="#" class="btn btn-primary-gradient ml-4 mt-2 "><i class="typcn typcn-shopping-cart mr-1"></i>Buy Now</a>
									</span>
								</div>
							</div> -->
						</div>
						<!--End Page header-->

                        <!-- search-client-info -->
                                                        <div class="search-client-info">
                                                            <div class="row">
						                                	    <div class="col-lg-12 col-md-12">
						                                	    	<div class="card">
						                                	    		<div class="card-header">
						                                	    			<h3 class="card-title">Add Account Master Details</h3>
						                                	    		</div>
						                                	    		<div class="card-body">
                                                                            <div class="row">
                                                                                <div class="col">
                                                                                	<div class="form-group">
                                                                                	    <label for="uname">Account Name <span class="text-danger">*</span> :</label>
                                                                                	    <input type="text" class="form-control" placeholder="" >
                                                                                	</div>
                                                                            	</div>
                                                                            	<div class="col">
                                                                            	    <div class="form-group">
                                                                            	        <label for="uname">Bank Name <span class="text-danger">*</span> :</label>
                                                                            	        <input type="text" class="form-control" id="email" placeholder="" name="email">
                                                                            	    </div>
                                                                            	</div>
                                                                            	<div class="col">
                                                                            	    <div class="form-group">
                                                                            	        <label for="uname">Branch :</label>
                                                                            	        <input type="text" class="form-control" placeholder="" name="pswd">
                                                                            	    </div>
                                                                            	</div>
                                                                            	
                                                                            </div>

                                                                            <div class="row">
                                                                                <div class="col">
                                                                                	<div class="form-group">
                                                                                	    <label for="uname">IFSC <span class="text-danger">*</span> :</label>
                                                                                	    <input type="text" class="form-control" placeholder="" >
                                                                                	</div>
                                                                            	</div>
                                                                            	<div class="col">
                                                                            	    <div class="form-group">
                                                                            	        <label for="uname">Bank Address <span class="text-danger">*</span> :</label>
                                                                            	        <input type="text" class="form-control" id="email" placeholder="" name="email">
                                                                            	    </div>
                                                                            	</div>
                                                                            	<div class="col">
                                                                            	    <div class="form-group">
                                                                            	        <label for="uname">Account Number :</label>
                                                                            	        <input type="text" class="form-control" placeholder="" name="pswd">
                                                                            	    </div>
                                                                            	</div>
                                                                            	
                                                                            </div>

                                                                            <div class="row">
                                                                                <div class="col">
                                                                                	<div class="form-group">
                                                                                	    <label for="uname">Account Holder Address <span class="text-danger">*</span> :</label>
                                                                                	    <textarea class="form-control" rows="3" id="comment"></textarea>
                                                                                	</div>
                                                                            	</div>
                                                                            	<div class="col">
                                                                            	    <div class="form-group">
                                                                            	        <label for="uname">Bank Address <span class="text-danger">*</span> :</label>
                                                                            	        <textarea class="form-control" rows="3" id="comment"></textarea>
                                                                            	    </div>
                                                                            	</div>
                                                                            </div>

                                                                            <div class="row">
                                                                                <div class="col">
                                                                                    <button type="submit" class="btn btn-primary d-block m-auto">Add</button>
                                                                                </div>
                                                                            </div>

						                                	    		</div>
						                                	    	</div>
						                                	    </div>
						                                    </div>
                                                        </div>
						                                <!-- End search-client-info -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\microtech\resources\views\account-master.blade.php ENDPATH**/ ?>